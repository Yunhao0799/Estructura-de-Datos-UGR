#ifndef Diccionario_h
#define Diccionario_h


#include "Termino.h"
#include <string>
#include<iostream>
#include "Vector_Dinamico.h"
using namespace std;

/**
 * @brief T.D.A Diccionario
 * Una variable de la clase Diccionario estara
 * formado por un conjunto de terminos
 * 
 * Un ejemplo de su uso
 * @include pruebadiccionario.cpp
 * 
 * @author Yunhao Lin
 * @author con la colaboración de Andrés Pérez
 * @date Sábado, 27 de octubre 2018
 * */

class Diccionario{
    private:
        Vector_Dinamico<Termino> terminos;
    
    public:
        /**
         * @brief Constructor de por defecto
         *
         */
        Diccionario();

        /** @brief Constructor por parametros
         * @param termino variable de la clase Termino
         */
        Diccionario(Termino);

        /** @brief constructor de copia
         * @param otra variable que representa otro direccionario
         */
        Diccionario(Diccionario&);

        //getters

        /**
         * @brief Definiciones de una palabra dada
         * @param buscado Termino del que queremos obtener las definiciones
         * @return salida Devuelve un vector dinamico de tipo string
         */
        Vector_Dinamico<string> getDefinicionesPalabra(Termino) const;

        /**
         * @brief Todos los terminos del diccionario
         * @return terminos Devuelve un vector dinamico de tipo Termino
         */
        Vector_Dinamico<Termino> getAllTerms() const;
        
        /**
         * @brief Total de terminos
         * @return Devuelve un entero con la cantidad de terminos del diccionario
         */
        int getNumTerminos() const;
	
        /**
         * @brief Termino en esa posicion
         * @param index Posicion de la que queremos obtener el termino
         * @return Devuelve el termino en la posicion index
         */
	    Termino getTermino(int index) const;



        //setters

        /** 
         * @brief Añade un termino
         * @param  nuevo Termino a añadir
         */
        void setNewTerm(Termino);

        /** 
         * @brief Elimina un termino
         * @param  eliminar Termino a eliminar
         */
        void eliminarTermino(Termino);

        //metodo que nos devuelve la posicion a la que se encuentra un termino
        /** 
         * @brief Elimina un termino
         * @param  nuevo Termino a buscar
         * @return pos Devuelve la posicion si existe el termino, si no devuelve -1
         */
        int buscarTermino(Termino);

        /**
         * @brief Entrada de un diccionario desde istream
         * @param is stream de entrada
         * @param d Diccionario que recibe el valor
         * @retval El Diccionario leído en d
         * @pre La entrada tiene el formato Palabra; definicion
         */
        friend istream& operator>> (istream &is, Diccionario& d);

        /**
         * @brief Salida de un Diccionario a ostream
         * @param os stream de salida
         * @param d Diccionario a escribir
         * @post Se imprime  un Termino
         */
        friend ostream& operator<< (ostream &os, const Diccionario &d);

        /**
         * @brief Filtrado por Intervalo
         * Dado un diccionario, 
         * el objetivo es obtener un subconjunto de este 
         * diccionario que incluya únicamente los términos
         * cuya palabra asociada esté en elintervalo 
         * especificado por[carácter_inicio, carácter_fin]
         * @param ini Caracter de inicio
         * @param fin Caracter de fin
         * @return salida Diccionario que empieza en el caracter dado y 
         *          termina en el caracter fin
         */
        Diccionario filtroIntervalo(string, string);

        /**
         * @brief FIltrado por palabra clave
         * Dado un diccionario, el objetivo es obtener un subconjuntode 
         * este diccionario que incluya únicamente las palabras en cuya 
         * definición aparezcala palabra clave. Si una palabra tiene 
         * varias definiciones, solo se devolverían como re-sultado del 
         * filtrado por palabra clave aquellas definiciones relacionadas 
         * con la palabraclave
         * @param a_buscar String que contiene la secuencia a buscar
         * @return salida Diccionario que contiene los terminos que tiene la palabra dada
         */
        Diccionario subsecuencia(string);


        /**
         * @brief Recuento de definiciones
         * Dado un diccionario, el objetivo es obtener el número total
         * de definiciones, el máximo de definiciones asociadas a una única 
         * palabra y el promediode definiciones por palabra
         * @param totalDefiniciones Double pasado por referencia y almacena el total de definiciones
         * @param maxDefiniciones Double pasado por referencia y almacena la palabra con mas definicones(cantidad)
         * @param promedio
         */
        void recuento(double&, double&, double&);
};

          

#endif
