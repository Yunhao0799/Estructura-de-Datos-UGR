#ifndef Termino_h
#define Termino_h

#include <string>
#include<iostream>
#include "Vector_Dinamico.h"
using namespace std;

/**
 * @brief T.D.A TErmino
 * Una variable de la clase Termino estara
 * formado por un string con el nombre del termino
 * y un vector dinamico con las definiciones
 * 
 * 
 * @author Yunhao Lin
 * @date Sábado, 27 de octubre 2018
 * */

class Termino{
    private:
        string palabra;
        Vector_Dinamico<string> definicion;
    public:
        //constructor por defecto
        /**
         * @brief Constructor de por defecto
         *
         */
        Termino();

        //contructor por parametros
        /** @brief Constructor por parametros
         * @param palabra Variable de tipo string
         * @param def Vector dinamico con las definiciones
         */
        Termino(string, Vector_Dinamico<string>);

        //constructor de copia
        /**
         * @brief Constructor de copia
         * @param otra Variable de la clase termino a copiar
         */ 
        Termino(const Termino&);

        //Getters
        /**
         * @brief Devuelve el nombre del termino
         * @return palabra
         */
        string getPalabra() const;

        /**
         * @brief Devuelve todas las definiciones que hay
         * @return definicion Vector dinamico con las definiciones
         */
        Vector_Dinamico<string> getDefinicionesAsociadas() const;

        /**
         * @brief Devuelve la cantidad de definiciones que hay
         * @return Un entero con la cantidad de definiciones
         */
        int getNAsociados() const;

        /**
         * @brief Devuelve la definicion en esa posicion
         * @return Un string con la definicion
         */
        string getDefinicion(int) const;


        //setters
        /**
         * @brief Cambia el nombre de palabra
         * @param palabra String
         */
        void setPalabra(string);

        /**
         * @brief Cambia el nombre de palabra
         * @param defini Vector dinamico de tipo string
         */
        void setDefiniciones(Vector_Dinamico<string> defini);

        
        /**
         * @brief Entrada de un termino desde istream
         * @param is stream de entrada
         * @param t termino que recibe el valor
         * @retval El termino leído en t
         */
        friend istream& operator>>(istream &is, Termino &t);

        /**
         * @brief Salida de un Termino a ostream
         * @param os stream de salida
         * @param t Termino a escribir
         * @post Se imprime el nombre del termino y a continuacion las definiciones asociadas
         */
        friend ostream& operator<<(ostream &os, const Termino &t);
};

#endif
