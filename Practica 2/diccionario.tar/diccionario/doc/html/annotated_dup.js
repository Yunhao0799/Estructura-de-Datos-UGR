var annotated_dup =
[
    [ "Diccionario", "classDiccionario.html", "classDiccionario" ],
    [ "Termino", "classTermino.html", "classTermino" ],
    [ "Vector_Dinamico", "classVector__Dinamico.html", "classVector__Dinamico" ]
];