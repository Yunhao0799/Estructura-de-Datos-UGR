var classDiccionario =
[
    [ "Diccionario", "classDiccionario.html#aa0a2191ec706b256c35b5229cc197b15", null ],
    [ "Diccionario", "classDiccionario.html#a66d1be3d00372c7b99ba85ffc4a2fbd5", null ],
    [ "Diccionario", "classDiccionario.html#a9e04e8c2ac73cd86cfa3e7a2edea6024", null ],
    [ "buscarTermino", "classDiccionario.html#acdee1c7bd378cd6e8385987ca6ffad91", null ],
    [ "eliminarTermino", "classDiccionario.html#ab3544dc006cd4f1113d92eaa59679a42", null ],
    [ "filtroIntervalo", "classDiccionario.html#accee4f0eafc150f76c84207ca90e62a3", null ],
    [ "getAllTerms", "classDiccionario.html#a0d0f7a4ff86974bcfec3de296ddfda6b", null ],
    [ "getDefinicionesPalabra", "classDiccionario.html#ad01e3b512d1ae3341df1d455a2caaef7", null ],
    [ "getNumTerminos", "classDiccionario.html#ae6d984ee1c3d6efa0748ef9708e6959c", null ],
    [ "getTermino", "classDiccionario.html#aa7d59adae9f6e13f942433de6e811eac", null ],
    [ "recuento", "classDiccionario.html#a968fac6ee482292295dcba86b7bde1f6", null ],
    [ "setNewTerm", "classDiccionario.html#aa900fbb4f2ced8a2aadbabd3dba106c2", null ],
    [ "subsecuencia", "classDiccionario.html#a2e9b111cc34cda87735d02e71dbae9f0", null ],
    [ "operator<<", "classDiccionario.html#a3d353aed1ab1b515fcf2be6172123b1e", null ],
    [ "operator>>", "classDiccionario.html#a37fecf9dd09405cc2cc91e81bf32cab0", null ],
    [ "terminos", "classDiccionario.html#ae7fbbf82df9ab6f4be8808981d7f7f93", null ]
];