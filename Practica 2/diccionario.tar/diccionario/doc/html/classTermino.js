var classTermino =
[
    [ "Termino", "classTermino.html#ac3b1425fec4d38d78c5d36cb5fe8e728", null ],
    [ "Termino", "classTermino.html#a0bea3afac4f2d981cc562690e50faab7", null ],
    [ "Termino", "classTermino.html#ae399e6aea2cde280d2a2e8b7a787f99d", null ],
    [ "getDefinicion", "classTermino.html#a96db92587260900e7b592149587f2e61", null ],
    [ "getDefinicionesAsociadas", "classTermino.html#aafa125b7dfd51be4c6fa39300096fb3c", null ],
    [ "getNAsociados", "classTermino.html#adb234e720e2dd95cd777651e20c47538", null ],
    [ "getPalabra", "classTermino.html#aca7e4f7a65e39d79ce59be80c6b88690", null ],
    [ "setDefiniciones", "classTermino.html#aa83f3619eedfd66a82e471e6d6327226", null ],
    [ "setPalabra", "classTermino.html#abcc09e4a7ea67209ab4bd4f8d090b8a7", null ],
    [ "operator<<", "classTermino.html#a990203f35e5916790b154a3eb6baf829", null ],
    [ "operator>>", "classTermino.html#a076140e7b0c3bcbe8182d5d201725f9f", null ],
    [ "definicion", "classTermino.html#ac17ce3c88d38d094c0cb572b0c9b03f0", null ],
    [ "palabra", "classTermino.html#aa55f0db9f49be5bf785a7bf53aedd684", null ]
];