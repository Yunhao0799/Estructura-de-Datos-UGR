var classRacional =
[
    [ "Racional", "classRacional.html#a05130ab34147ac85a4e340a33c82deb2", null ],
    [ "Racional", "classRacional.html#a5b8490366043f82fcc83cb827197fc05", null ],
    [ "Racional", "classRacional.html#a6c5adcd48e75a23200f2db70bd13101b", null ],
    [ "asignar", "classRacional.html#ad5a5b3220853ced644fef769e122cf52", null ],
    [ "comparar", "classRacional.html#a585a90e00a35d0d00576af756ab301f0", null ],
    [ "denominador", "classRacional.html#a222dded5259ed20fc4c40ffbe9d6b9a7", null ],
    [ "numerador", "classRacional.html#a7457006396e7609e8a03af043a86afbb", null ],
    [ "operator+", "classRacional.html#aa4539b99ed60caa9a107a1c0b4f28aa2", null ],
    [ "operator+=", "classRacional.html#a1d1cccc4b27d5b232070cfe503565a02", null ],
    [ "operator==", "classRacional.html#a3ff869f17b7ba36d10cad60eff8e894d", null ],
    [ "print", "classRacional.html#ab30e69922f714ac6c79ec2628b301274", null ],
    [ "simplifica", "classRacional.html#a33114260605dc5f5659d9a83f9bb6047", null ],
    [ "operator<<", "classRacional.html#a4335a71aa6c96ff2f0cb5aee0f3961a1", null ],
    [ "operator>>", "classRacional.html#a32a42bfb8bd87c71444f292d8f8d09be", null ],
    [ "den", "classRacional.html#aee8b1719744e807c0498b89b9ff90276", null ],
    [ "num", "classRacional.html#a1a053a6a9d6adee4cfc73b1cb8e3305c", null ]
];