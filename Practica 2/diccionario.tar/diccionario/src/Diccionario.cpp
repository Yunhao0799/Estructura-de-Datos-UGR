#include "Diccionario.h"



Diccionario::Diccionario(){

}

Diccionario::Diccionario(Termino termino){
    terminos[0] = termino;
}

Diccionario::Diccionario(Diccionario &otra){
    terminos = otra.getAllTerms();
}


Vector_Dinamico<string> Diccionario::getDefinicionesPalabra(Termino buscado) const{
    Vector_Dinamico<string> salida;

    for(int i = 0; i < terminos.size(); i++){
        if(terminos[i].getPalabra() == buscado.getPalabra())
            salida = terminos[i].getDefinicionesAsociadas();
    }
    return salida;
}

Vector_Dinamico<Termino> Diccionario::getAllTerms() const{
    return terminos;
}

int Diccionario::getNumTerminos() const{
    return terminos.size();
}

void Diccionario::setNewTerm(Termino nuevo){
    int pos = buscarTermino(nuevo);
	bool salir = false;
	
    if(pos == -1){
        
        //redimensionamos
        terminos.resize(terminos.size() + 1);
        //buscamos la posicion en la que deberia estar
        for(int i = 0; i < terminos.size() && !salir; i++){
            if(!(nuevo.getPalabra() > terminos[i].getPalabra())){
                pos = i; 
                salir = true;
            }
        }
        if (!salir)
        	pos = terminos.size()-1;
        //desplazaomos el vector a la derecha
        for(int i = terminos.size() - 1; i > pos; i--)
            terminos[i] = terminos[i - 1];
        
        //y añadimos el nuevo termino en la posicion 
        terminos[pos] = nuevo;    
    }
    else cout << "este termino ya existe \n"; 
}

void Diccionario::eliminarTermino(Termino eliminar){
    int pos = buscarTermino(eliminar);

    for(int i = pos; i < terminos.size() - 1; i++)
        terminos[i] = terminos[i + 1];
    
    terminos.resize(terminos.size() - 1);
}

int Diccionario::buscarTermino(Termino nuevo){
    int centro = 0, inf = 0, sup = terminos.size() - 1, pos = -1;

    
    while(inf <= sup){
        centro = ((sup - inf)/2) + inf;
        if(terminos[centro].getPalabra() == nuevo.getPalabra())
            pos = centro;
        else if (nuevo.getPalabra() < terminos[centro].getPalabra())
            sup = centro - 1;
        else 
            inf = centro + 1;

    }

    return pos;
}

Termino Diccionario::getTermino(int index) const{
	return terminos[index];
}




istream& operator>>(istream &is, Diccionario &d){
    Termino este, siguiente;
    is >> este;
    while(!is.eof()){
        is >> siguiente;
        while(siguiente.getPalabra() == este.getPalabra()){
            este.setDefiniciones(siguiente.getDefinicionesAsociadas());
            is >> siguiente;    
        }
        d.setNewTerm(este);
        if(!is.eof())
            este = siguiente;
    }

    return is;
}


ostream& operator<< (ostream &os, const Diccionario &d){
    for(int i = 0; i < d.getNumTerminos(); i++)
        os << d.getTermino(i) << endl;
    
    return os;
}

Diccionario Diccionario::filtroIntervalo(string ini, string fin){
    Diccionario salida;
    //string ini = inicio, fin = final1;

    //la letra de inicio tiene que ser mas pequeña (en ASCII)
    if(ini < fin){
        cout << "intervalo incorrecto \n";
        exit;
    }
    
    int pos;
    bool salir = false;
    //tenemos que encontrar donde empieza el filtro
    //buscamos la posicion en la que deberia estar
    for(int i = 0; i < terminos.size() && !salir; i++){
        if(!(ini > terminos[i].getPalabra())){
            pos = i; 
            salir = true;
        }
    }

    bool fin1 = false;
    string aux;
    int tam_fin = fin.length(), j;
    int i = pos;
    while( i < terminos.size() - 1 && !fin1 ){
        salida.setNewTerm(terminos[i]);
        aux = terminos[i + 1].getPalabra();
        if (fin < aux){
        for(j = 0; j < tam_fin; j++){
            if (fin[j] != aux[j])
                fin1 = true;
        }}

        i++;
    }    
    /*
    for(int i = pos; i < terminos.size() && !fin1; i++){
        salida.setNewTerm(terminos[i]);
        aux = terminos[i].getPalabra();
        if(aux.find(fin) == string::npos)
            fin1 = true;
    }*/

    return salida;
}

Diccionario Diccionario::subsecuencia(string a_buscar){
    Diccionario salida;
    Termino aux;
    Vector_Dinamico<string> aux2;
    string aux1;
    for(int i = 0; i < terminos.size(); i++){
        aux = terminos[i];
        aux2 = aux.getDefinicionesAsociadas();
        for(int j = 0; j < aux2.size(); j++){
            aux1 = aux2[j];
            if(aux1.find(a_buscar) != string::npos)
                salida.setNewTerm(aux);
        }
    }

    return salida;
}

void Diccionario::recuento(double &totalDefiniciones, double &maxDefiniciones, double &promedio){
    Termino aux;
    double def;
    totalDefiniciones = 0.0;
    maxDefiniciones = 0.0;
    promedio = 0.0;
    if(terminos.size() > 0){
        for(int i = 0; i < terminos.size(); i++){
            aux = terminos[i];
            def = (aux.getDefinicionesAsociadas()).size();
            totalDefiniciones += def;
            if(def > maxDefiniciones)
                maxDefiniciones = def;
        }
        promedio = totalDefiniciones/(terminos.size() * 1.0);
    }
}