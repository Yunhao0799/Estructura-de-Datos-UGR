#include "Diccionario.h"
#include <fstream>
#include <iostream>

using namespace std;

int main(int argc, char * argv[]){

  if (argc!=2){
      cout<<"Dime el nombre del fichero con el diccionario"<<endl;
      return 0;
   }

   ifstream f (argv[1]);
   if (!f){
    cout<<"No puedo abrir el fichero "<<argv[1]<<endl;
    return 0;
   }
   
   Diccionario mi_diccionario;
   f>>mi_diccionario; //Cargamos en memoria el diccionario
   
   cout << "\n \n \n";
   cout << "Diccionario completo:";
   cout << "\n \n \n";
   cout << mi_diccionario << endl;
   cout << "\n \n \n";
   
   cout << "Diccionario de copia completo:";
   Diccionario mi_diccionario2(mi_diccionario);
   cout << "\n \n \n";
   cout << mi_diccionario2 << endl;
   cout << "\n \n \n";
   /* Exhibir aqui la funcionalidad programada para el TDA Diccionario / TDA Termino  
    Algunas sugerencias: 
    - Obtener las definiciones asociadas a una palabra   
    - Obtener el (sub)diccionario de términos comprendidos en [caracter_inicial, caracter_final]
    - Obtener el (sub)diccionario de términos asociados a una palabra clave. Ejemplo: el diccionario de terminos asociados a "color"   
    - Obtener el numero total de definiciones, el maximo de definiciones asociadas a una unica palabra y el promedio de definiciones por palabra
    - Cualquier otra funcionalidad que considereis de interes 
   */
    cout << "Prueba filtro por intervalo \n";
    Diccionario dic1;
    dic1 = mi_diccionario.filtroIntervalo("a", "b");
    cout << dic1 << endl;
    cout << "\n \n \n";

    cout << "Prueba filtro por palabra dada \n";
    Diccionario dic2;
    dic2 = mi_diccionario.subsecuencia("Constantine");
    cout << dic2 << endl;
    cout << "\n \n \n";

    double definiciones, maximo;
    double media;
    mi_diccionario.recuento(definiciones, maximo, media);
    cout << "Total de definiciones: " << definiciones << endl;
    cout << "Maximo de definiciones: " << maximo << endl;
    cout << "Promedio de definiciones: " << media << endl;
}
